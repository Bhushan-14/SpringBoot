package com.example.demo.dao.entities;

import jakarta.persistence.*;
import lombok.*;
import java.util.Set;

@Entity
@Table(name = "departments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Department {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    
    private boolean isActive = true;
    private boolean isDeleted = false;

    @ManyToMany(mappedBy = "departments")
    private Set<Employee> employees;
}
