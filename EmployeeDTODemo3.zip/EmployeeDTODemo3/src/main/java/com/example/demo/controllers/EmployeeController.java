package com.example.demo.controllers;

import com.example.demo.dto.EmployeeDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employees")
public interface EmployeeController {

    @GetMapping("/getEmployee")
    ResponseEntity<List<EmployeeDTO>> getAllEmployees();

    @GetMapping("/getEmployee/{id}")
    ResponseEntity<EmployeeDTO> getEmployeeById(@PathVariable Integer id);

    @PostMapping("/addEmployee")
    ResponseEntity<EmployeeDTO> createEmployee(@RequestBody EmployeeDTO employeeDTO);

    @PutMapping("/updateEmployee/{id}")
    ResponseEntity<EmployeeDTO> updateEmployeeById(@PathVariable Integer id, @RequestBody EmployeeDTO employeeDTO);

    @DeleteMapping("/deleteEmployee/{id}")
    ResponseEntity<String> deleteEmployeeById(@PathVariable Integer id);
}
