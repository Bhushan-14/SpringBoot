package com.example.demo.services;

import com.example.demo.dto.EmployeeDTO;

import java.util.List;

public interface EmployeeService {
    List<EmployeeDTO> getAllEmployees();
    EmployeeDTO getEmployeeById(Integer id);
    EmployeeDTO createEmployee(EmployeeDTO employeeDTO);
    EmployeeDTO updateEmployeeById(Integer id, EmployeeDTO employeeDTO);
    void deleteEmployeeById(Integer id);
}
