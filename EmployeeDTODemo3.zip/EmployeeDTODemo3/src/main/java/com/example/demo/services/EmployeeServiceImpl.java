package com.example.demo.services;

import com.example.demo.dao.entities.Employee;
import com.example.demo.dao.repositries.EmployeeRepo;
import com.example.demo.dto.EmployeeDTO;
import com.example.demo.mapper.EmployeeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepo employeeRepository;

    @Override
    @Transactional(readOnly = true)
    public List<EmployeeDTO> getAllEmployees() {
        List<Employee> employees = employeeRepository.findByIsDeletedFalse();
        return employees.stream()
                .map(EmployeeMapper.INSTANCE::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public EmployeeDTO getEmployeeById(Integer id) {
        Employee employee = employeeRepository.findByEmployeeIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
        return EmployeeMapper.INSTANCE.toDTO(employee);
    }

    @Override
    @Transactional
    public EmployeeDTO createEmployee(EmployeeDTO employeeDTO) {
        Employee employee = EmployeeMapper.INSTANCE.toEntity(employeeDTO);
        employee.setIsDeleted(false); 
        employeeRepository.save(employee);
        return EmployeeMapper.INSTANCE.toDTO(employee);
    }

    @Override
    @Transactional
    public EmployeeDTO updateEmployeeById(Integer id, EmployeeDTO employeeDTO) {
        Employee existingEmployee = employeeRepository.findByEmployeeIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));

        existingEmployee.setName(employeeDTO.getName());
        existingEmployee.setEmail(employeeDTO.getEmail());

        employeeRepository.save(existingEmployee);
        return EmployeeMapper.INSTANCE.toDTO(existingEmployee);
    }

    @Override
    @Transactional
    public void deleteEmployeeById(Integer id) {
        Employee existingEmployee = employeeRepository.findByEmployeeIdAndIsDeletedFalse(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
        
        existingEmployee.setIsDeleted(true); 
        employeeRepository.save(existingEmployee);
    }
}
