package com.example.demo.dao.repositories;

import com.example.demo.dao.entities.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Query("SELECT e FROM Employee e WHERE e.isActive = true ORDER BY e.id DESC")
    List<Employee> findAllActiveEmployees();

    @Query("SELECT e FROM Employee e WHERE e.id = :id AND e.isActive = true")
    Optional<Employee> findActiveEmployeeById(@Param("id") Long id);

    @Query("SELECT e FROM Employee e WHERE e.name = :name AND e.isActive = true")
    Employee findByEmployeeName(@Param("name") String name);
}
