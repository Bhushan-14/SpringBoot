package com.example.demo.controller;

import com.example.demo.dto.EmployeeDTO;
import com.example.demo.dto.response.EmployeeApiResponse;
import com.example.demo.service.EmployeeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Service
@Slf4j
public class EmployeeControllerImpl implements EmployeeController {

    @Autowired
    private EmployeeService service;

    @Override
    public ResponseEntity<EmployeeApiResponse> getById(Long id) {
        log.info("Fetching Employee by ID: {}", id);
        ResponseEntity<EmployeeApiResponse> response = new ResponseEntity<>(service.getEmployeeById(id), HttpStatus.OK);
        log.info("Employee fetch completed.");
        return response;
    }

    @Override
    public ResponseEntity<EmployeeApiResponse> getAll() {
        log.info("Fetching all employees.");
        ResponseEntity<EmployeeApiResponse> response = new ResponseEntity<>(service.getAllEmployees(), HttpStatus.OK);
        log.info("Employee fetch completed.");
        return response;
    }

    @Override
    public ResponseEntity<EmployeeApiResponse> addEmployee(EmployeeDTO employeeDto) {
        log.info("Adding new employee.");
        ResponseEntity<EmployeeApiResponse> response = new ResponseEntity<>(service.createEmployee(employeeDto), HttpStatus.OK);
        log.info("Employee added successfully.");
        return response;
    }

    @Override
    public ResponseEntity<EmployeeApiResponse> updateEmployee(EmployeeDTO employeeDto) {
        log.info("Updating employee with ID: {}", employeeDto.getId());
        ResponseEntity<EmployeeApiResponse> response = new ResponseEntity<>(service.updateEmployee(employeeDto.getId(), employeeDto), HttpStatus.OK);
        log.info("Employee update completed.");
        return response;
    }

    @Override
    public ResponseEntity<EmployeeApiResponse> deleteById(Long id) {
        log.info("Deleting employee with ID: {}", id);
        ResponseEntity<EmployeeApiResponse> response = new ResponseEntity<>(service.deleteEmployee(id), HttpStatus.OK);
        log.info("Employee deletion completed.");
        return response;
    }
}
