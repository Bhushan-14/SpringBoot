package com.example.demo.controller;

import com.example.demo.dto.EmployeeDTO;
import com.example.demo.dto.response.EmployeeApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/employee")
public interface EmployeeController {

    @GetMapping("/getById/{id}")
    ResponseEntity<EmployeeApiResponse> getById(@PathVariable("id") Long id);

    @GetMapping("/getAll")
    ResponseEntity<EmployeeApiResponse> getAll();

    @PostMapping("/addEmployee")
    ResponseEntity<EmployeeApiResponse> addEmployee(@RequestBody EmployeeDTO employeeDto);

    @PutMapping("/updateEmployee")
    ResponseEntity<EmployeeApiResponse> updateEmployee(@RequestBody EmployeeDTO employeeDto);

    @DeleteMapping("/deleteById/{id}")
    ResponseEntity<EmployeeApiResponse> deleteById(@PathVariable("id") Long id);
}
