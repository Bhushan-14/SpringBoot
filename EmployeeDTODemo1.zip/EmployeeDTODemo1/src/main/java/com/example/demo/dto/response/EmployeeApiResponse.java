package com.example.demo.dto.response;

import com.example.demo.dto.EmployeeDTO;
import lombok.*;
import org.springframework.http.HttpStatus;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmployeeApiResponse {
    private EmployeeDTO employeeDTO;
    private List<EmployeeDTO> employeeDTOs;
    private HttpStatus status;
    private String message;
    private boolean error;
}
